import { Section } from "../../components/ui/section";
import { HeroContent } from "./HeroContent";
import { HeroImage } from "./HeroImage";

export function Hero() {
  return (
    <Section className="px-0">
      <div className="relative overflow-hidden">
        <HeroImage />

        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />

        <div className="absolute inset-x-0 bottom-0">
          <HeroContent />
        </div>
      </div>
    </Section>
  );
}