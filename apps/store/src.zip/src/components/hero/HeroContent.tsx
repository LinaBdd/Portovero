import { H1, Lead } from "../../components/ui/typography";
import { HeroBadge } from "./HeroBadge";
import { HeroButtons } from "./HeroButtons";

export function HeroContent() {
  return (
    <div className="mx-auto w-full max-w-7xl px-5 pb-8 pt-24 text-white sm:px-8 sm:pb-12 lg:px-12 lg:pb-16">
      <HeroBadge />

      <H1
        className="
          mt-4
          max-w-2xl
          font-normal
          text-[2.8rem]
          leading-[0.95]
          tracking-[-0.035em]
          sm:text-5xl
          lg:text-7xl
        "
      >
        Timeless pieces
        <br />
        for everyday
        <br />
        <span className="italic">elegance.</span>
      </H1>

      <Lead
        className="
          mt-5
          max-w-sm
          text-sm
          leading-6
          text-white/85
          sm:text-base
        "
      >
        Discover our curated collection of timeless
        pieces, crafted with uncompromising attention
        to detail.
      </Lead>

      <div className="mt-6">
        <HeroButtons />
      </div>
    </div>
  );
}