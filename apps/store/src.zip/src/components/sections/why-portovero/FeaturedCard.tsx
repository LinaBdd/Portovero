import { type LucideIcon } from "lucide-react";

type FeatureCardProps = {
  title: string;
  description: string;
  icon: LucideIcon;
};

export function FeatureCard({
  title,
  description,
  icon: Icon,
}: FeatureCardProps) {
  return (
    <div className="flex items-start gap-4 py-6 sm:gap-5 sm:py-7">
      <Icon
        size={17}
        strokeWidth={1.25}
        className="mt-0.5 shrink-0 text-muted-foreground"
        aria-hidden="true"
      />

      <div className="min-w-0">
        <h3 className="text-sm font-medium tracking-wide">
          {title}
        </h3>

        <p className="mt-1.5 text-xs leading-6 text-muted-foreground sm:text-sm">
          {description}
        </p>
      </div>
    </div>
  );
}