import { Section } from "../../ui/section";
import { H2, Lead } from "../../ui/typography";
import { FeatureCard } from "./FeaturedCard";
import { features } from "./data";

export function WhyPortovero() {
  return (
    <Section className="px-5 py-16 sm:px-6 sm:py-20 lg:py-28">
      <div className="mx-auto mb-10 max-w-2xl text-center sm:mb-14">
        <p className="mb-3 text-[10px] font-medium uppercase tracking-[0.28em] text-muted-foreground">
          The Portovero Standard
        </p>

        <H2 className="text-3xl font-normal tracking-[-0.02em] sm:text-4xl">
          Why Portovero
        </H2>

        <Lead className="mx-auto mt-4 max-w-lg text-sm leading-7 text-muted-foreground sm:text-base">
          Luxury isn't just about clothing. It's about confidence,
          quality and timeless style.
        </Lead>
      </div>

      <div className="mx-auto max-w-4xl divide-y divide-border border-y border-border">
        {features.map((feature) => (
          <FeatureCard
            key={feature.title}
            {...feature}
          />
        ))}
      </div>
    </Section>
  );
}